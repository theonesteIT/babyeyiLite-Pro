const express = require('express');
const { promisePool } = require('../config/database');

const router = express.Router();

function requireTeacherRole(req, res, next) {
    if (!req.session?.userId) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    // Specific role filtering optionally added here
    next();
}

function resolveSchoolId(req) {
    return (
        req.session?.school_id ||
        req.session?.user?.school_id ||
        req.user?.school_id ||
        null
    );
}

function resolveUserId(req) {
    return req.session?.userId || req.session?.user?.id || req.user?.id || null;
}

let teacherTablesReady = false;
async function ensureTeacherTables() {
    if (teacherTablesReady) return;

    await promisePool.query(`
      CREATE TABLE IF NOT EXISTS academic_timetables (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        school_id INT UNSIGNED NOT NULL,
        class_name VARCHAR(120) NOT NULL,
        subject_name VARCHAR(120) NOT NULL,
        staff_id INT UNSIGNED NOT NULL,
        day_of_week VARCHAR(20) NOT NULL,
        start_time VARCHAR(20) NOT NULL,
        end_time VARCHAR(20) NOT NULL,
        room VARCHAR(64) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_tt_school_staff (school_id, staff_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    await promisePool.query(`
      CREATE TABLE IF NOT EXISTS academic_attendance_logs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        school_id INT UNSIGNED NOT NULL,
        timetable_id INT UNSIGNED NOT NULL,
        record_date DATE NOT NULL,
        session_status VARCHAR(32) DEFAULT 'Completed',
        recorded_by_user_id INT UNSIGNED NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_att_log_date (school_id, timetable_id, record_date)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    await promisePool.query(`
      CREATE TABLE IF NOT EXISTS academic_attendance_records (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        log_id INT UNSIGNED NOT NULL,
        student_id INT UNSIGNED NOT NULL,
        status VARCHAR(32) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_att_rec (log_id, student_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    await promisePool.query(`
      CREATE TABLE IF NOT EXISTS academic_assessments (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        school_id INT UNSIGNED NOT NULL,
        class_name VARCHAR(120) NOT NULL,
        subject_name VARCHAR(120) NOT NULL,
        assessment_name VARCHAR(120) NOT NULL,
        max_score DECIMAL(8,2) NOT NULL DEFAULT 100,
        assessment_type VARCHAR(32) DEFAULT 'TEACHER_CUSTOM',
        created_by_user_id INT UNSIGNED NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_assess_school (school_id, class_name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    await promisePool.query(`
      CREATE TABLE IF NOT EXISTS academic_marks (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        school_id INT UNSIGNED NOT NULL,
        assessment_id INT UNSIGNED NOT NULL,
        student_id INT UNSIGNED NOT NULL,
        score_obtained DECIMAL(8,2) NOT NULL,
        recorded_by_user_id INT UNSIGNED NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_student_assessment (assessment_id, student_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    teacherTablesReady = true;
}

// Ensure middleware hook runs for routes
router.use(async (req, res, next) => {
    try {
        await ensureTeacherTables();
        next();
    } catch (e) {
        console.error('Failed to init teacher tables:', e);
        res.status(500).json({ success: false, message: 'Database initialization failed.' });
    }
});

// ============================================================
// GET /api/teacher-portal/dashboard
// ============================================================
router.get('/dashboard', requireTeacherRole, async (req, res) => {
    try {
        const schoolId = resolveSchoolId(req);
        const userId = resolveUserId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const [[studentCount]] = await promisePool.query('SELECT COUNT(*) as c FROM students WHERE school_id = ?', [schoolId]);

        // Get actual today schedule
        const currentDay = new Date().toLocaleString('en-US', { weekday: 'long' });
        const [todayScheduleRows] = await promisePool.query(
          'SELECT subject_name as subject, class_name as `group`, room, CONCAT(start_time, " - ", end_time) as time FROM academic_timetables WHERE school_id = ? AND staff_id = ? AND day_of_week = ? ORDER BY start_time ASC',
          [schoolId, userId, currentDay]
        );

        const stats = [
            { label: 'Total Classes', value: todayScheduleRows.length },
            { label: 'Active Students', value: String(studentCount?.c || 0) },
            { label: 'Today Attendance', value: '0%' }, // Requires aggregating status from attendance records
            { label: 'Lessons Done', value: '0' },
        ];

        res.json({ success: true, data: { stats, schedule: todayScheduleRows } });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to fetch dashboard stats' });
    }
});

// ============================================================
// ============================================================
// GET /api/teacher-portal/students
// ============================================================
router.get('/students', requireTeacherRole, async (req, res) => {
    try {
        const schoolId = resolveSchoolId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const { class_name } = req.query;
        let query = 'SELECT * FROM students WHERE school_id = ?';
        let params = [schoolId];

        if (class_name) {
            query += ' AND class_name = ?';
            params.push(class_name);
        }

        query += ' ORDER BY first_name ASC LIMIT 100';
        const [rows] = await promisePool.query(query, params);

        let totalAttendance = 0;
        let epicCount = 0;

        const data = rows.map((r, i) => {
            const gpaValue = (Math.random() * (4.0 - 2.5) + 2.5);
            const attendanceValue = Math.floor(Math.random() * (100 - 80) + 80);
            
            totalAttendance += attendanceValue;
            if (gpaValue > 3.4) epicCount++;

            return {
                row_id: r.id,
                id: r.student_uid,
                name: `${r.first_name} ${r.last_name}`,
                grade: r.class_name || 'Unassigned',
                stream: '',
                gpa: gpaValue.toFixed(1),
                attendance: attendanceValue,
                status: gpaValue > 3.4 ? 'Epic' : 'Average',
                parent: r.father_full_name || 'Not provided',
                phone: r.father_phone || 'Not provided',
                email: r.father_email || 'Not provided',
                province: r.province || 'N/A',
                district: r.district || 'N/A',
                sector: r.sector || 'N/A',
                cell: r.cell || 'N/A',
                created_at: r.created_at,
            };
        });

        const stats = {
            totalEnrolled: data.length,
            epicPercent: data.length > 0 ? Math.round((epicCount / data.length) * 100) : 0,
            avgAttendance: data.length > 0 ? (totalAttendance / data.length).toFixed(1) : 0,
            diversityIndex: (Math.random() * (1.5 - 0.8) + 0.8).toFixed(1), // keep one mock or actual based on gender
        };

        res.json({ success: true, data, stats });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to fetch students' });
    }
});

// ============================================================
// GET /api/teacher-portal/english-club/resources
// ============================================================
router.get('/english-club/resources', requireTeacherRole, (req, res) => {
    // Mocked curated resources for English Club
    const resources = [
        {
            id: 1,
            title: 'Modern Pedagogy Essentials',
            description: 'A comprehensive guide to task-based language teaching in Rwandan schools.',
            content_type: 'pdf',
            thumbnail_url: null,
            resource_url: '#'
        },
        {
            id: 2,
            title: 'Classroom Management in EFL',
            description: 'Effective strategies for maintaining engagement during large language sessions.',
            content_type: 'video',
            thumbnail_url: null,
            resource_url: '#'
        },
        {
            id: 3,
            title: 'Grammar Instruction Masterclass',
            description: 'Techniques for teaching complex tenses without losing students interest.',
            content_type: 'video',
            thumbnail_url: null,
            resource_url: '#'
        },
        {
            id: 4,
            title: 'Phonetics & Pronunciation Hub',
            description: 'Audio resources and exercises for improving students oral proficiency.',
            content_type: 'quiz',
            thumbnail_url: null,
            resource_url: '#'
        }
    ];

    const { type } = req.query;
    const filtered = type && type !== 'all' 
        ? resources.filter(r => r.content_type === type)
        : resources;

    res.json({ success: true, resources: filtered });
});

// ============================================================
// GET /api/teacher-portal/classes
// ============================================================
router.get('/classes', requireTeacherRole, async (req, res) => {
    try {
        const schoolId = resolveSchoolId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const [rows] = await promisePool.query(
            'SELECT DISTINCT class_name FROM students WHERE school_id = ? AND class_name IS NOT NULL AND class_name != "" ORDER BY class_name ASC', 
            [schoolId]
        );

        const classes = rows.map(r => r.class_name);
        res.json({ success: true, data: classes });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to fetch classes' });
    }
});

// ============================================================
// GET /api/teacher-portal/timetable
// ============================================================
router.get('/timetable', requireTeacherRole, async (req, res) => {
    try {
        const schoolId = resolveSchoolId(req);
        const userId = resolveUserId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const { day } = req.query;
        let query = 'SELECT id, subject_name as subject, class_name as `group`, room, CONCAT(start_time, " - ", end_time) as time, day_of_week as day FROM academic_timetables WHERE school_id = ? AND staff_id = ?';
        let params = [schoolId, userId];

        if (day) {
            query += ' AND day_of_week = ?';
            params.push(day);
        }

        query += ' ORDER BY start_time ASC';
        const [rows] = await promisePool.query(query, params);

        res.json({ success: true, data: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to fetch timetable' });
    }
});

// ============================================================
// POST /api/teacher-portal/attendance
// ============================================================
router.post('/attendance', requireTeacherRole, async (req, res) => {
    const conn = await promisePool.getConnection();
    try {
        const schoolId = resolveSchoolId(req);
        const userId = resolveUserId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const { timetable_id, date, records } = req.body;
        if (!timetable_id || !date || !records || !Array.isArray(records)) {
             return res.status(400).json({ success: false, message: 'Invalid specific payload format' });
        }

        await conn.beginTransaction();

        const [logRes] = await conn.query(
            'INSERT INTO academic_attendance_logs (school_id, timetable_id, record_date, recorded_by_user_id) VALUES (?, ?, ?, ?)',
            [schoolId, timetable_id, date, userId]
        );
        const logId = logRes.insertId;

        for (const r of records) {
            await conn.query(
               'INSERT INTO academic_attendance_records (log_id, student_id, status) VALUES (?, ?, ?)',
               [logId, r.student_id, r.status]
            );
        }

        await conn.commit();
        res.json({ success: true, message: 'Attendance registered successfully' });
    } catch (err) {
        await conn.rollback().catch(()=>{});
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to register attendance' });
    } finally {
        conn.release();
    }
});

// ============================================================
// POST /api/teacher-portal/assessments
// ============================================================
router.post('/assessments', requireTeacherRole, async (req, res) => {
    try {
        const schoolId = resolveSchoolId(req);
        const userId = resolveUserId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const { class_name, subject_name, assessment_name, max_score } = req.body;
        if (!class_name || !subject_name || !assessment_name) {
            return res.status(400).json({ success: false, message: 'Missing fields' });
        }

        const [r] = await promisePool.query(
            'INSERT INTO academic_assessments (school_id, class_name, subject_name, assessment_name, max_score, assessment_type, created_by_user_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [schoolId, class_name, subject_name, assessment_name, max_score || 100, 'TEACHER_CUSTOM', userId]
        );

        res.json({ success: true, assessment_id: r.insertId, message: 'Assessment created' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to create assessment' });
    }
});

// ============================================================
// POST /api/teacher-portal/marks
// ============================================================
router.post('/marks', requireTeacherRole, async (req, res) => {
    try {
        const schoolId = resolveSchoolId(req);
        const userId = resolveUserId(req);
        if (!schoolId) return res.status(400).json({ success: false, message: 'No school linked' });

        const { assessment_id, marks } = req.body;
        if (!assessment_id || !marks || !Array.isArray(marks)) {
             return res.status(400).json({ success: false, message: 'Invalid payload format' });
        }

        for (const m of marks) {
             await promisePool.query(
                 'INSERT INTO academic_marks (school_id, assessment_id, student_id, score_obtained, recorded_by_user_id) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE score_obtained = VALUES(score_obtained)',
                 [schoolId, assessment_id, m.student_id, m.value, userId]
             );
        }

        res.json({ success: true, message: 'Marks saved successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: 'Failed to record marks' });
    }
});

module.exports = router;
